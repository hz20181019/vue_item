<template>
    <div>详情页</div>
</template>