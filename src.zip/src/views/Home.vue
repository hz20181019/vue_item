<template>
  <div class="home">
      这是首页
      <Banner :sliders="sliders"/>
  </div>
</template>

<script>
import Banner from '../components/Banner'
export default {
  name: 'home',
  data(){
    return{
      sliders:[1,2,3,4]
    }
  },
  //template中的data要写成函数
  components: {
    Banner
  }
}
</script>
